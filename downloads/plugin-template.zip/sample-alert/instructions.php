<div class="container mt-2">
    <div class="card">
        <div class="card-header">
            <h1>Sample Alert Plugin</h1>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-8 p-2 border-end">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#description">Description</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#installation">Installation</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#faq">FAQ</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#changelog">Changelog</a>
                        </li>
                    </ul>

                    <div class="tab-content">
                        <div id="description" class="container tab-pane active"><br>
                            <p>This is a simple demo plugin that allows you to display a custom JavaScript alert message on your website's front-end.</p>
                            <p>You can configure the alert message and enable/disable the alert from the plugin's settings page.</p>
                        </div>
                        <div id="installation" class="container tab-pane fade"><br>
                            <p>Installation is handled automatically by the CMS. Simply activate the plugin from the Plugins management page.</p>
                            <p>Ensure your database has the necessary permissions for table creation and data insertion.</p>
                        </div>
                        <div id="faq" class="container tab-pane fade"><br>
                            <h6>How do I change the alert message?</h6>
                            <p>Navigate to the "Manage" section of this plugin and update the "Alert Message" field.</p>
                            <h6>How do I stop the alert from showing?</h6>
                            <p>Uncheck the "Enable Alert" switch in the plugin's settings and save your changes.</p>
                        </div>
                        <div id="changelog" class="container tab-pane fade"><br>
                            <p><strong>Version 1.0.0 (July 25, 2025)</strong></p>
                            <ul>
                                <li>Initial release.</li>
                                <li>Added ability to set custom alert message.</li>
                                <li>Added enable/disable functionality.</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-4 p-4">
                    <p><span class="fw-bold">Name</span> : Sample Alert Plugin</p>
                    <p><span class="fw-bold">Version</span> : 1.0.0</p>
                    <p><span class="fw-bold">Author</span> : Your Name</p>
                    <p><span class="fw-bold">Requires PHP Version</span> : 8.0 or higher</p>
                    <p><span class="fw-bold">Compatible With</span> : CodeIgniter 4.3+</p>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button type="button" class="btn btn-success float-end">Active</button>
        </div>
    </div>
</div>