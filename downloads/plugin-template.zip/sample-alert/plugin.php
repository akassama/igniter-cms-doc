<?php

if (!function_exists('sample_alert_display')) {
    /**
     * Displays a JavaScript alert with a custom message if enabled.
     */
    function sample_alert_display()
    {
        try {
            // Get configuration from icp_sample_alert_config
            $config = getTableData('icp_sample_alert_config', [], '*');

            if ($config && $config->enable_alert == 1 && !empty($config->alert_message)) {
                echo '<script>';
                echo 'alert("' . esc($config->alert_message) . '");';
                echo '</script>';
            }
        } catch (\Exception $e) {
            log_message('error', 'Sample Alert Plugin failed to display alert: ' . $e->getMessage());
        }
    }
}

// Call the function immediately when the plugin is loaded
sample_alert_display();