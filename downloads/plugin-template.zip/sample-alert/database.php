<?php
$pluginKey = "sample-alert";

// Create table icp_sample_alert_config
$createTablesQuery = "
CREATE TABLE icp_sample_alert_config (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    alert_message TEXT NOT NULL,
    enable_alert TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

// Insert initial data for plugin
$createTableDataQuery = "
INSERT INTO icp_sample_alert_config (
    alert_message,
    enable_alert
) VALUES (
    'Hello from Sample Alert Plugin!',
    1
);
";

// Optional for Config Data - Sample insert data for plugin_configs
$createConfigQuery = "
INSERT INTO plugin_configs (plugin_slug, config_key, config_value) VALUES
('$pluginKey', 'initial_setup', '1');
";
?>