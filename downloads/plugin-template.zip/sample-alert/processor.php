<?php

namespace Plugins\SampleAlert;

use Config\Database;

class Processor
{
    /**
     * Processes plugin configuration updates for the Sample Alert plugin.
     *
     * @param array $postData Raw POST data from the form
     * @param string $pluginKey The plugin key (e.g., sample-alert)
     * @return bool True on success, throws exception on failure
     * @throws \Exception If validation or database operation fails
     */
    public function processPluginFormData($postData, $pluginKey)
    {
        // Sanitize and validate input
        $alertMessage = trim($postData['alertMessage'] ?? '');
        $enableAlert = isset($postData['enableAlert']) ? 1 : 0; // Checkbox value

        if (empty($alertMessage)) {
            throw new \Exception("Alert message cannot be empty.");
        }

        // Table name for sample-alert
        $configTableName = "icp_sample_alert_config";

        // Check if table exists
        $db = Database::connect();
        $tables = $db->listTables();
        if (!in_array($configTableName, $tables)) {
            throw new \Exception("Configuration table does not exist: {$configTableName}");
        }

        // Prepare data
        $data = [
            'alert_message' => $alertMessage,
            'enable_alert' => $enableAlert
        ];

        // Check if a record already exists to determine if we should update or insert
        $existingRecord = $db->table($configTableName)->get()->getRow();

        if ($existingRecord) {
            // Update the existing record
            $db->table($configTableName)
                ->where('id', $existingRecord->id)
                ->update($data);
        } else {
            // Insert a new record
            $db->table($configTableName)->insert($data);
        }

        // Log success
        log_message('debug', "Updated data for plugin: {$pluginKey}");

        return true;
    }
}