<?php
// Get configuration from icp_sample_alert_config (single record)
$config = getTableData('icp_sample_alert_config', [], '*');

$alertMessage = $config->alert_message ?? 'Hello from Sample Alert Plugin!';
$enableAlert = $config->enable_alert ?? 0;
?>

<div class="container-fluid p-3">
    <div class="row justify-content-center">
        <div class="col-md-10 col-sm-12">
            <h4 class="mb-4">Sample Alert Plugin Settings</h4>
            <?php $validation = \Config\Services::validation(); ?>
            <?php echo form_open(base_url('account/plugins/manage/sample-alert'), 'method="post" class="row g-3 needs-validation save-changes" enctype="multipart/form-data" novalidate'); ?>

                <div class="row mb-3">
                    <div class="col-12">
                        <label for="alertMessage" class="form-label">Alert Message</label>
                        <textarea class="form-control" id="alertMessage" name="alertMessage" rows="3" required><?= esc($alertMessage) ?></textarea>
                        <div class="invalid-feedback">
                            Please enter an alert message.
                        </div>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-12">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" id="enableAlert" name="enableAlert" <?= $enableAlert ? 'checked' : '' ?>>
                            <label class="form-check-label" for="enableAlert">Enable Alert</label>
                        </div>
                    </div>
                </div>

                <div class="row mt-4">
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-success me-2">
                            <i class="bi bi-save"></i> Save Settings
                        </button>
                        <button type="button" class="btn btn-outline-secondary" id="resetForm">
                            <i class="bi bi-arrow-counterclockwise"></i> Reset
                        </button>
                    </div>
                </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Reset form
    $('#resetForm').click(function() {
        // You might want to reload the page or reset specific fields
        window.location.reload();
    });
});
</script>